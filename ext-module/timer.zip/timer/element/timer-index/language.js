export const lang = {
  "it": {
    "list-timer": "Lista timer",
    "insert-timer": "Inserisci timer",
    "update-timer": "Aggiorna timer",
    "add": "aggiungi"
  },
  "en": {
    "list-timer": "List timer",
    "insert-timer": "Insert timer",
    "update-timer": "Update timer",
    "add": "add"
  }
};
