/**
 * Config
 */
export const config = {
    
}