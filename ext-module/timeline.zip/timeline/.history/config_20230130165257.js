/**
 * Config
 */
export const config = {
    "timeline" : {
        "timeline": {
            "storage": {
                "name-service": "PlaylistStorage",
                "adapter": {
                    "mongo": {
                        "collection": "timeline",
                        "connection-service": "MongoDb"
                    },
                    "dexie": {
                        "collection": "timeline",
                        "connection-service": "DexieManager"
                    }
                }
            }, 
            "entityService": "PlaylistEntity",
            "entityServiceTimeslotRef": "TimeslotPlaylistReference",
            "acl": {
                "resource": 'playlist'
            },
            "hydrator": {
                "name-storage-service": "PlaylistEntityHydrator",
            },
            "playlistService": "PlaylistService"
        }
    }
}