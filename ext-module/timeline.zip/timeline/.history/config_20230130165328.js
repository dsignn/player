/**
 * Config
 */
export const config = {
    "timeline" : {
        "timeline": {
            "storage": {
                "name-service": "PlaylistStorage",
                "adapter": {
                    "mongo": {
                        "collection": "timeline",
                        "connection-service": "MongoDb"
                    },
                    "dexie": {
                        "collection": "timeline",
                        "connection-service": "DexieManager"
                    }
                }
            }, 
            "entityService": "PlaylistEntity",
            "entityServiceTimeslotRef": "TimeslotPlaylistReference",
            "acl": {
                "resource": 'timeline'
            },
            "hydrator": {
                "name-storage-service": "TimelineEntityHydrator",
            },
            "playlistService": "TimelineService"
        }
    }
}