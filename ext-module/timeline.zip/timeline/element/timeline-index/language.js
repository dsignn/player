export const lang = {
  "it": {
    "list-timeline": "Lista timeline",
    "insert-timeline": "Inserisci timeline",
    "update-timeline": "Aggiorna timeline",
    "add": "aggiungi"
  },
  "en": {
    "list-timeline": "List timeline",
    "insert-timeline": "Insert timeline",
    "update-timeline": "Update timeline",
    "add": "add"
  }
};
