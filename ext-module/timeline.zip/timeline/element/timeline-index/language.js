export const lang = {
  "it": {
    "list-timeline": "Lista timeline",
    "insert-timeline": "Inserisci timeline",
    "update-timeline": "Aggiorna timeline",
    "add": "aggiungi",
    "name": "Nome",
  },
  "en": {
    "list-timeline": "List timeline",
    "insert-timeline": "Insert timeline",
    "update-timeline": "Update timeline",
    "add": "add",
    "name": "Name",
  }
};
