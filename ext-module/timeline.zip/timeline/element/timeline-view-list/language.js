export const lang = {
    "it": {
        "header": "Lista timeline",
        "notify-delete": "Timeline eliminata"
    },
    "en": {
        "header": "List timeline",
        "notify-delete": "Timeline deleted"
    }
};
