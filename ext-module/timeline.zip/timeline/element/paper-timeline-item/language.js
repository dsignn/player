export const lang = {
  "it": {
    "delete" : "Elimina",
    "timeslot" : "Timeslot"
  },
  "en": {
    "delete" : "Delete",
    "timeslot" : "Timeslot"
  }
};
