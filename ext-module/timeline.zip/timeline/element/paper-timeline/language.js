export const lang = {
  "it": {
    "modify": "Modifica",
    "delete" : "Elimina",
    "play-timeline" : "Avvia timeline",
    "pause-timeline" : "Metti in pausa timeline",
    "stop-timeline" : "Stoppa timelien"
  },
  "en": {
    "modify": "Modify",
    "delete" : "Delete",
    "play-timeline" : "Play timeline",
    "pause-timeline" : "Pause timeline",
    "stop-timeline" : "Stop timeline"
  }
};
