(async () => {
    const { html, PolymerElement } = await import(require('path').normalize(
        `${container.get('Application').getNodeModulePath()}/@polymer/polymer/polymer-element.js`));
  
    /**
     *
     */
    class WcParking extends PolymerElement {

        static get template() {
            return html`        
            <style>

                #camera {
                    height: 100%;
                    width: 100%;
                    object-fit: fill;
                }

            </style>
            <div>_tcpSource</div>
            `;
        }

        static get properties () {
            return {

                tcpSource: {
                    type: Object,
                    notify: true,
                    observer: '_tcpSource',
                }
            }
        }

        /**
         * @param newValue
         * @param oldValue
         * @private
         */
        _tcpSource(newValue, oldValue) {
                console.log('_tcpSource');
            
        }
    }

    window.customElements.define('wc-parking', WcParking);

})();