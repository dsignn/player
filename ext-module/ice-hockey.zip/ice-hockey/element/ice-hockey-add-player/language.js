export const lang = {
  "it": {
    "player": "Giocatore",
    "firstName": "Nome",
    "lastName": "Cognome",
    "role": "Ruolo",
    "shirtNumber": "Numero di maglietta",
    "add": "Aggiungi",
    "update": "Modifica"
  },
  "en": {
    "player": "Player",
    "firstName": "First name",
    "lastName": "last name",
    "role": "Role",
    "shirtNumber": "Shirt number",
    "add": "Add",
    "update": "Update"
  }
};