export const lang = {
  "it": {
    "header": "Lista monitor",
    "notify-delete": "Monitor eliminato",
    "empty-ice-hockey": "Non sono presenti partite"
  },
  "en": {
    "header": "List monitor",
    "notify-delete": "Monitor deleted",
    "empty-ice-hockey": "No ice hockey match loaded"
  }
};