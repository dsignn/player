export const lang = {
  "it": {
    "modify": "Modifica",
    "delete" : "Elimina",
    "preview-resource": "Preview della risorsa"
  },
  "en": {
    "modify": "Modify",
    "delete" : "Delete",
    "preview-resource": "Resource preview "
  }
};