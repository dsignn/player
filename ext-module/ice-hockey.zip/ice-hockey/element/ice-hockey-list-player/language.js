export const lang = {
  "it": {
    "header": "Lista monitor",
    "notify-delete": "Monitor eliminato"
  },
  "en": {
    "header": "List monitor",
    "notify-delete": "Monitor deleted"
  }
};