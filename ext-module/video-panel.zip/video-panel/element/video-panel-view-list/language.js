export const lang = {
    "it": {
        "header": "Lista quadro video",
        "notify-delete": "Quadro video eliminata"
    },
    "en": {
        "header": "List video panel",
        "notify-delete": "Video panel deleted"
    }
};
