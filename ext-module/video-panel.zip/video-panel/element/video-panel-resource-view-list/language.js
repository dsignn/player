export const lang = {
    "it": {
        "header": "Lista risorse quadro video",
        "notify-delete": "Risorsa quadro video eliminata"
    },
    "en": {
        "header": "List video panel resource",
        "notify-delete": "Video panel resource deleted"
    }
};
