export const lang = {
  "it": {
    "modify": "Modifica",
    "delete" : "Elimina",
    "play-timer" : "Start timer",
    "stop-timer" : "Resetta timer",
    "pause-timer" : "Pause timer"


  },
  "en": {
    "modify": "Modify",
    "delete" : "Delete",
    "play-timer" : "Start timer",
    "stop-timer" : "Reset timer",
    "pause-timer" : "Pause timer"
  }
};
