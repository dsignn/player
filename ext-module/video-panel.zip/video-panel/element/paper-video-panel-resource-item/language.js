export const lang = {
  "it": {
    "resource": "Risorsa"

  },
  "en": {
    "resource": "Resource"
  }
};
