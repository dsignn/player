export const lang = {
  "it": {
    "point": "Punto",
    "time": "Tempo",
    "period": "Periodo",
    "add": "Aggiungi",
    "update": "Modifica"
  },
  "en": {
    "point": "Point",
    "time": "Time",
    "period": "Period",
    "add": "Add",
    "update": "Update"
  }
};