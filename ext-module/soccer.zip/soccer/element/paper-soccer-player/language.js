export const lang = {
  "it": {
    "modify": "Modifica",
    "delete" : "Elimina",
    "preview-resource": "Preview della risorsa",
    "set-point": "Aggiungi punto"
  },
  "en": {
    "modify": "Modify",
    "delete" : "Delete",
    "preview-resource": "Resource preview",
    "set-point": "Set point"
  }
};