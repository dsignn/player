export const lang = {
    "it": {
        "header": "Lista media device",
        "notify-delete": "Media device eliminata"
    },
    "en": {
        "header": "List media device",
        "notify-delete": "Media device deleted"
    }
};
