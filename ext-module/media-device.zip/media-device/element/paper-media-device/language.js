export const lang = {
  "it": {
    "modify": "Modifica",
    "delete" : "Elimina"
  },
  "en": {
    "modify": "Modify",
    "delete" : "Delete"
  }
};
