export const lang = {
  "it": {
    "list-media-device": "Lista media device",
    "insert-media-device": "Inserisci media device",
    "update-media-device": "Aggiorna media device",
    "add": "aggiungi"
  },
  "en": {
    "list-media-device": "List media device",
    "insert-media-device": "Insert media device",
    "update-media-device": "Update media device",
    "add": "add"
  }
};
