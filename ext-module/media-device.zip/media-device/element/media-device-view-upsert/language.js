export const lang = {
  "it": {
    "header": "Lista media device",
    "name" : "Nome",
    "save": "Salva",
    "update": "Modifica",
    "notify-save" : "Media device saved",
    "notify-update" : "Media device updated"
  },
  "en": {
    "header": "List media device",
    "name" : "Name",
    "save": "Save",
    "update": "Update",
    "notify-save" : "Media device salvato",
    "notify-update" : "Media device aggiornato"
  }
};
