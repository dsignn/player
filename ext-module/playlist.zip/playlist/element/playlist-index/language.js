export const lang = {
  "it": {
    "list-playlist": "Lista playlist",
    "insert-playlist" : "Inserisci playlist",
    "update-playlist" : "Modifica playlist",
    "back" : "Torna indietro",
    "playlist-data": "Dati playlist",
    "name": "Nome",
  },
  "en": {
    "list-playlist": "List playlist",
    "insert-playlist" : "Insert playlist",
    "update-playlist" : "Update playlist",
    "back" : "Back",
    "playlist-data": "playlist data",
    "name": "Name",
  }
};
