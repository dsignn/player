export const lang = {
    "it": {
        "header": "Lista playlist",
        "notify-delete": "Playlist eliminata"
    },
    "en": {
        "header": "List playlist",
        "notify-delete": "Playlist deleted"
    }
};
