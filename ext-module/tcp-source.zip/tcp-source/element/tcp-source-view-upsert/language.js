export const lang = {
  "it": {
    "header": "Lista source",
    "name" : "Nome",
    "ip": "Indirizzo ip",
    "port": "Porta",
    "interval": "Intervallo di chiamata",
    "save": "Salva",
    "notify-save" : "Playlist saved",
    "notify-update" : "Playlist updated"
  },
  "en": {
    "header": "List source",
    "name" : "Name",
    "ip": "Ip address",
    "port": "Port",
    "port": "Port",
    "interval": "Call interval",
    "save": "Save",
    "notify-save" : "Playlist salvata",
    "notify-update" : "Playlist aggiornata"
  }
};
