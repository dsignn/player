export const lang = {
    "it": {
        "header": "Lista playlist",
        "notify-delete": "Playlist eliminata",
        "empty-tcp-source": "Nessuna source inserita"
    },
    "en": {
        "header": "List playlist",
        "notify-delete": "Playlist deleted",
        "empty-tcp-source": "Nothing source saved"
    }
};
