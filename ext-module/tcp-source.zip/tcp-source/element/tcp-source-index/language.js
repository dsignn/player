export const lang = {
  "it": {
    "list-tcp-source": "Lista source",
    "insert-tcp-source" : "Inserisci source",
    "update-tcp-source" : "Modifica source",
    "back" : "Torna indietro",
    "tcp-source-data": "Dati source",
    "name": "Nome",
  },
  "en": {
    "list-tcp-source": "List source",
    "insert-tcp-source" : "Insert source",
    "update-tcp-source" : "Update source",
    "back" : "Back",
    "tcp-source-data": "source data",
    "name": "Name",
  }
};
