export const lang = {
    "it": {
        "title": "Scoreboard del calcio"
    },
    "en": {
        "title": "Scoreboard soccer"
    }
};
