const JsonParser = (async () => {
    
    /**
     * @class PlaylistEntity
     */
    class JsonParser {

        constructor() {

        }
    }

    return {JsonParser: JsonParser};
})();

export default JsonParser;
export const then = JsonParser.then.bind(JsonParser);