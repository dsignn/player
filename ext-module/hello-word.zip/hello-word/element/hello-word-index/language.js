export const lang = {
  "it": {
    "test": "Test italiano",
  },
  "en": {
    "test": "Test English",
  }
};
