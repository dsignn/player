/**
 * Config
 */
export const config = {
    "modules": {
        "hello-word" : {
            "hello-word": {
                "acl": {
                    "resource": 'hello-word'
                }
            }
        }
    }
}