/**
 * Config
 */
export const config = {
    "hello-word": {
        "hello-word": {
            "acl": {
                "resource": 'hello-word'
            }
        }
    }
}