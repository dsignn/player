import {PolymerElement, html} from '@polymer/polymer/polymer-element'

/**
 *
 */
class WcResourceTest extends PolymerElement {

    static get template() {
        return html`
            <div>${test}</div>
        `;
    }

    static get properties () {
        return {

            test: {
                type: String
            }
        }
    }

    /**
     *
     */
    createMockData() {
        this.test = 'Messaggio di test';
    }
}
