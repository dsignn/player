import { IceHockeyMatch } from '@dsign/library/src/sport/ice-hockey/match/IceHockeyMatch';
import {html, PolymerElement} from '@polymer/polymer/polymer-element'

/**
 *
 */
class WcResourceIceHockeyScoreboard extends PolymerElement {

    static get template() {
        return html`
        <style>

            .match {
                padding: 0;
                height: 100%;
                width: 100%;
                color: white;
                font-size: 30px;
            }

            .match {
                display: none;
            }

        </style>
            <div id="match" class="match hidden">
                {{match.name}}
            </div>
        </template>
        `;
    }

    static get properties() {
        return {

            match: {
                type: Object,
                notify: true,
                observer: '_iceHockeyMatchChanged',
                value: new IceHockeyMatch()
            }
        };
    }

    ready() {
        super.ready();

       // require('electron').ipcRenderer.on(TimerService.DATA, this._updateTimer.bind(this));
       // require('electron').ipcRenderer.on(TimerService.START, this._updateTimer.bind(this));
        setTimeout(
            () => { this.$.timer.classList.remove('hidden')},
            1100
        )
    }

    /**
     * @param newValue
     */
     _iceHockeyMatchChanged(newValue) {
        if (!newValue) {
            return;
        }

        console.log('MATCH', newValue);
    }

    /**
     *
     */
    createMockData() { }
}

window.customElements.define('wc-resource-ice-hockey-scoreboard', WcResourceIceHockeyScoreboard);
